/**
 * Created by zhufu on 19/1/22.
 */
/**
 * Created by zhufu on 19/1/22.
 */
import SocketController from './data/socket-controller';
import TianBa from './data/tianba';
const  global = {};
global.socket = SocketController();
global.tianba = TianBa();
export default global;