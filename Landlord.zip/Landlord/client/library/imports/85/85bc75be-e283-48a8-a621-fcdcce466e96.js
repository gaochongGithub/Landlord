"use strict";
cc._RF.push(module, '85bc7W+4oNIqKYh/NzORm6W', 'tianba');
// script/data/tianba.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _playerData = require('./player-data');

var _playerData2 = _interopRequireDefault(_playerData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var TianBa = function TianBa() {
    var that = {};
    that.playerData = (0, _playerData2.default)();
    return that;
}; /**
    * Created by zhufu on 19/1/22.
    */
exports.default = TianBa;
module.exports = exports['default'];

cc._RF.pop();