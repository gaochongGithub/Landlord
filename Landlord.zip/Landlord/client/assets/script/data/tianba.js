/**
 * Created by zhufu on 19/1/22.
 */
import PalyerData from './player-data'
const TianBa = function(){
    let that = {};
    that.playerData = PalyerData();
    return that;
}
export default TianBa;