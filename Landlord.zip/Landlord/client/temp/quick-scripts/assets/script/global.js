(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/global.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0d9b4uxFGtBV7f7m+T5Cdu1', 'global', __filename);
// script/global.js

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _socketController = require('./data/socket-controller');

var _socketController2 = _interopRequireDefault(_socketController);

var _tianba = require('./data/tianba');

var _tianba2 = _interopRequireDefault(_tianba);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by zhufu on 19/1/22.
 */
/**
 * Created by zhufu on 19/1/22.
 */
var global = {};
global.socket = (0, _socketController2.default)();
global.tianba = (0, _tianba2.default)();
exports.default = global;
module.exports = exports['default'];

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=global.js.map
        