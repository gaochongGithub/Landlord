"use strict";
cc._RF.push(module, '0d9b4uxFGtBV7f7m+T5Cdu1', 'global');
// script/global.js

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _socketController = require('./data/socket-controller');

var _socketController2 = _interopRequireDefault(_socketController);

var _tianba = require('./data/tianba');

var _tianba2 = _interopRequireDefault(_tianba);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by zhufu on 19/1/22.
 */
/**
 * Created by zhufu on 19/1/22.
 */
var global = {};
global.socket = (0, _socketController2.default)();
global.tianba = (0, _tianba2.default)();
exports.default = global;
module.exports = exports['default'];

cc._RF.pop();