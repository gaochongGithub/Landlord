"use strict";
cc._RF.push(module, '42c9ervILBPdbop/NKfV8GZ', 'socket-controller');
// script/data/socket-controller.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _defines = require('./../defines');

var _defines2 = _interopRequireDefault(_defines);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SocketController = function SocketController() {
    var that = {};
    var _socket = undefined;
    that.init = function () {
        _socket = io(_defines2.default.serverUrl);
    };
    that.login = function (unique, nickName, abatarUrl, houseCount) {
        _socket.emit('login', {
            uniqueID: unique,
            nickName: nickName,
            abatarUrl: abatarUrl,
            houseCount: houseCount
        });
    };
    return that;
}; /**
    * Created by zhufu on 19/1/22.
    */
exports.default = SocketController;
module.exports = exports['default'];

cc._RF.pop();