/**
 * Created by zhufu on 19/1/22.
 */
const socket = require('socket.io');
const app = socket('3000');

app.on('connection',function(socket){
    console.log("user listen");
    socket.on('login',function(data){
        console.log(JSON.stringify(data)+'syk;');
    });
});