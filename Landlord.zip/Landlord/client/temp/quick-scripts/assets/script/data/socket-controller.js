(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/data/socket-controller.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '42c9ervILBPdbop/NKfV8GZ', 'socket-controller', __filename);
// script/data/socket-controller.js

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _defines = require('./../defines');

var _defines2 = _interopRequireDefault(_defines);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var SocketController = function SocketController() {
    var that = {};
    var _socket = undefined;
    that.init = function () {
        _socket = io(_defines2.default.serverUrl);
    };
    that.login = function (unique, nickName, abatarUrl, houseCount) {
        _socket.emit('login', {
            uniqueID: unique,
            nickName: nickName,
            abatarUrl: abatarUrl,
            houseCount: houseCount
        });
    };
    return that;
}; /**
    * Created by zhufu on 19/1/22.
    */
exports.default = SocketController;
module.exports = exports['default'];

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=socket-controller.js.map
        