"use strict";
cc._RF.push(module, '616ff/I9UhBVbWbm22d8IOk', 'defines');
// script/defines.js

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * Created by zhufu on 19/1/22.
 */
var defines = {};
defines.serverUrl = "http://localhost:3000";
exports.default = defines;
module.exports = exports["default"];

cc._RF.pop();