/**
 * Created by zhufu on 19/1/22.
 */
const PlayerData = function(){
    let that = {};
    that.uid = undefined;
    that.uniqueID = '10000';
    that.nickName = "小明"+Math.floor(Math.random()*10);
    that.abatarUrl ='https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3217773157,3211809052&fm=27&gp=0.jpg';
    that.houseCount = 0;
    for(let i=0;i<7;i++){
        that.uniqueID += Math.floor(Math.random()*10);
    }
    that.wxLoginSuccess = function(data){
        that.uniqueID = data.uniqueID;
        that.nickName = data.nickName;
        that.abatarUrl = data.abatarUrl;
        that.houseCount = data.houseCount;
    }
    that.loginSuccess = function(data){
        console.log(JSON.stringify((data)));
    }
    return that;
}
export default PlayerData;