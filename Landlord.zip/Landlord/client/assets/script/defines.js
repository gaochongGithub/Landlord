/**
 * Created by zhufu on 19/1/22.
 */
const defines = {};
defines.serverUrl = "http://localhost:3000";
export default defines;