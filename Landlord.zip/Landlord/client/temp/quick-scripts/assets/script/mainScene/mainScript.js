(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/mainScene/mainScript.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bc1eblxYrFM0pfLfMXziAiP', 'mainScript', __filename);
// script/mainScene/mainScript.js

'use strict';

var _global = require('./../global');

var _global2 = _interopRequireDefault(_global);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        _global2.default.socket.init();
    },
    btnClick: function btnClick(event, customData) {
        switch (customData) {
            case 'wxlogin':
                _global2.default.socket.login(_global2.default.tianba.playerData.uniqueID, _global2.default.tianba.playerData.nickName, _global2.default.tianba.playerData.abatarUrl, _global2.default.tianba.playerData.houseCount, function (err, data) {
                    if (err) {
                        console.log(err + '登录错误');
                    } else {
                        console.log(JSON.stringify(data) + '登录成功l');
                    }
                });
                break;
            default:
                break;
        }
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=mainScript.js.map
        