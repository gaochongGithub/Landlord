/**
 * Created by zhufu on 19/1/22.
 */
import defines from './../defines'
const  SocketController = function(){
    let that = {};
    let _socket = undefined;
    that.init = function(){
        _socket = io(defines.serverUrl);
    };
    that.login = function(unique,nickName,abatarUrl,houseCount){
        _socket.emit('login',{
            uniqueID:unique,
            nickName:nickName,
            abatarUrl:abatarUrl,
            houseCount:houseCount
        });
    }
    return that;
}
export default SocketController;