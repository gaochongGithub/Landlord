
import global from './../global'
cc.Class({
    extends: cc.Component,

    properties: {

    },

    // LIFE-CYCLE CALLBACKS:

     onLoad () {
         global.socket.init();
     },
    btnClick(event , customData){
        switch (customData){
            case 'wxlogin':
                global.socket.login(
                    global.tianba.playerData.uniqueID,
                    global.tianba.playerData.nickName,
                    global.tianba.playerData.abatarUrl,
                    global.tianba.playerData.houseCount,
                    function(err,data){
                        if(err){
                            console.log(err+'登录错误');
                        }else{
                            console.log(JSON.stringify(data)+'登录成功l');
                        }
                    }
                );
                break;
            default :
                break;
        }
    },


    // update (dt) {},
});
